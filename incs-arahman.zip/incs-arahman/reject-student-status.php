<?php
if(isset($_POST['reject_students'])){
echo ' <div class="row ">
<div class="col-12 grid-margin">
  <div class="card">
    <div class="card-body">
<label class="badge badge-info">You have denied and deleted the student details.</label>
</div>
</div>
</div>
</div>';

	
}